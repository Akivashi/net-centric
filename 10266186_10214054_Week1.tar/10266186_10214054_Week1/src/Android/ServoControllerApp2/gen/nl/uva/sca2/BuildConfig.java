/** Automatically generated file. DO NOT MODIFY */
package nl.uva.sca2;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}